# Changelog

## 2025-09-25T01:52:59.547646-03:00
- chore: bump version and add GitHub-recognizable changes (README/marker)
- fix: PWA assets moved to public/pwa, index.html service worker path corrected, SPA redirects ensured in netlify.toml

