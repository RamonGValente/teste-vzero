// Media inputs removed by request: camera, video, mic, and file attachments.
// This component is kept to avoid breaking imports, but renders nothing.
export const MediaMessageInput = () => null;
