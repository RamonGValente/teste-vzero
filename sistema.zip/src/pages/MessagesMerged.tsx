/**
 * MessagesMerged.tsx
 * (Placeholder explicativo)
 * A base de UI do chat foi copiada de sistema-excluindo para src/components/chat_from_excluindo
 * e as melhorias de tradução/exclusão foram mantidas em MessagesEnhanced.tsx.
 * Mantenha MessagesEnhanced como principal; este arquivo é apenas para referência/migração.
 */
export {};
