-- Disable RLS temporarily to test if the issue is RLS-related
ALTER TABLE conversations DISABLE ROW LEVEL SECURITY;