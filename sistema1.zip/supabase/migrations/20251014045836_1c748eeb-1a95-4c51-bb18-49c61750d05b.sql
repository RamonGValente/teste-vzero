-- Disable RLS on conversation_participants to test
ALTER TABLE conversation_participants DISABLE ROW LEVEL SECURITY;